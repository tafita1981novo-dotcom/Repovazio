"""
QUANTUM BRAIN v2.0 — Pipeline Completo de Monetização
100% gratuito: NVIDIA + Groq + Pollinations + gTTS + MoviePy + YouTube API
Afiliados de maior APV selecionados automaticamente (junho 2026)
"""

import os, json, requests, datetime
from pathlib import Path

# ── Credenciais (GitHub Secrets) ────────────────────────────────────────────
NVIDIA_API_KEY   = os.environ.get("NVIDIA_API_KEY2", "")
GROQ_API_KEY     = os.environ.get("GROQ_API_KEY2", "")
ELEVENLABS_KEY   = os.environ.get("ELEVENLABS_API_KEY2", "")
SUPABASE_URL     = os.environ.get("SUPABASE_URL2", "")
SUPABASE_KEY     = os.environ.get("SUPABASE_KEY2", "")
YOUTUBE_TOKEN    = os.environ.get("YOUTUBE_REFRESH_TOKEN2", "")
YT_CLIENT_ID     = os.environ.get("YOUTUBE_CLIENT_ID2", "")
YT_CLIENT_SECRET = os.environ.get("YOUTUBE_CLIENT_SECRET2", "")

# ── Top afiliados ClickBank junho 2026 (maior APV × maior conversão) ────────
# Selecionados por: APV alto + conversão comprovada + alinhamento ao nicho
AFFILIATE_LINKS = {
    "Billionaire Brain Wave": {
        "url":   "https://tafita1981.attractbr.hop.clickbank.net",
        "apv":   63.73,
        "epc":   1.68,
        "conv":  3.04,   # % conversão — maior da lista
        "desc":  "Ative ondas cerebrais Theta e atraia prosperidade"
    },
    "The Brain Song": {
        "url":   "https://tafita1981.brainsong.hop.clickbank.net",
        "apv":   55.00,
        "epc":   1.50,
        "conv":  2.80,
        "desc":  "Programa de NASA neurocientista para otimização cerebral"
    },
    "Individualist — Psicologia Junguiana": {
        "url":   "https://tafita1981.individua1.hop.clickbank.net",
        "apv":   48.00,
        "epc":   0.95,
        "conv":  1.20,
        "desc":  "Descubra seu arquétipo e transforme sua vida"
    },
    "Wealth DNA Code": {
        "url":   "https://tafita1981.wealthdna.hop.clickbank.net",
        "apv":   48.30,
        "epc":   0.39,
        "conv":  0.82,
        "desc":  "Ative o código de riqueza no seu DNA"
    }
}

def gerar_footer_afiliados() -> str:
    """Gera footer otimizado com os afiliados de maior potencial de receita."""
    footer = "\n\n━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    footer += "🔗 RECURSOS RECOMENDADOS:\n\n"
    for nome, dados in AFFILIATE_LINKS.items():
        footer += f"✅ {dados['desc']}:\n{dados['url']}\n\n"
    footer += "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    footer += "👍 Gostou? Deixe seu like e se inscreva!\n"
    footer += "🔔 Ative o sininho para não perder nenhum vídeo\n"
    footer += "💬 Comente sua experiência!\n"
    return footer

# ── LLM Router gratuito ──────────────────────────────────────────────────────
def call_llm(prompt: str, system: str = "", max_tokens: int = 3000) -> str:
    sys = system or "Você é especialista em criação de conteúdo viral em português brasileiro sobre psicologia e comportamento humano."

    # 1. NVIDIA DeepSeek (grátis)
    if NVIDIA_API_KEY:
        try:
            r = requests.post(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {NVIDIA_API_KEY}"},
                json={"model": "deepseek-ai/deepseek-r1",
                      "messages": [{"role":"system","content":sys},{"role":"user","content":prompt}],
                      "max_tokens": max_tokens, "temperature": 0.7},
                timeout=60
            )
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"]
        except: pass

    # 2. Groq (grátis, fallback)
    if GROQ_API_KEY:
        try:
            r = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
                json={"model": "llama-3.3-70b-versatile",
                      "messages": [{"role":"system","content":sys},{"role":"user","content":prompt}],
                      "max_tokens": max_tokens},
                timeout=60
            )
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"]
        except: pass

    return ""

# ── Trending topics ──────────────────────────────────────────────────────────
def pesquisar_trending() -> list:
    prompt = """Liste 10 títulos de vídeo YouTube com ALTO potencial viral agora em junho 2026.
Nicho: psicologia comportamental, autoconhecimento, mente e comportamento humano.
Use fórmulas validadas:
- "N sinais de [condição invisível]"
- "Por que [paradoxo emocional]"
- "A verdade desconfortável sobre [tema]"
- "Não é X, é Y"
Responda APENAS JSON: {"topics": ["titulo1", ...]}"""

    resp = call_llm(prompt)
    try:
        clean = resp.strip().replace("```json","").replace("```","").strip()
        return json.loads(clean).get("topics", [])
    except:
        return [
            "7 sinais de que você tem ansiedade silenciosa e não sabe",
            "Por que pessoas inteligentes se sabotam sem perceber",
            "A verdade desconfortável sobre relacionamentos tóxicos",
            "Não é preguiça, é esgotamento emocional — entenda a diferença",
            "5 comportamentos que parecem normais mas são trauma"
        ]

# ── Roteiro ──────────────────────────────────────────────────────────────────
def gerar_roteiro(titulo: str) -> dict:
    footer = gerar_footer_afiliados()
    prompt = f"""Crie roteiro COMPLETO para YouTube de 10 minutos sobre: "{titulo}"
Canal: psicologia e comportamento humano, português brasileiro.
Tom: pesquisadora de comportamento humano — empática, reveladora.
NUNCA use "psicóloga" ou "psicólogo".
Estrutura: hook 15s + promessa 30s + desenvolvimento com pattern interrupt + revelação central + CTA.
Responda APENAS JSON:
{{"titulo_otimizado":"...","descricao_youtube":"...","tags":["..."],"roteiro_completo":"...","prompt_thumbnail":"..."}}"""

    resp = call_llm(prompt, max_tokens=4000)
    try:
        clean = resp.strip().replace("```json","").replace("```","").strip()
        data = json.loads(clean)
        # Adicionar footer de afiliados na descrição
        data["descricao_youtube"] = data.get("descricao_youtube","") + footer
        return data
    except:
        return {
            "titulo_otimizado": titulo,
            "descricao_youtube": f"Neste vídeo: {titulo}" + footer,
            "tags": ["psicologia","comportamento","autoconhecimento"],
            "roteiro_completo": resp,
            "prompt_thumbnail": titulo
        }

# ── Voz ──────────────────────────────────────────────────────────────────────
def gerar_voz(texto: str, path: str) -> bool:
    # ElevenLabs free
    if ELEVENLABS_KEY:
        try:
            r = requests.post(
                "https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM",
                headers={"xi-api-key": ELEVENLABS_KEY, "Content-Type":"application/json"},
                json={"text": texto[:9000], "model_id":"eleven_multilingual_v2",
                      "voice_settings":{"stability":0.5,"similarity_boost":0.75}},
                timeout=120
            )
            if r.status_code == 200:
                open(path,"wb").write(r.content)
                return True
        except: pass

    # gTTS (100% grátis, ilimitado)
    try:
        from gtts import gTTS
        gTTS(text=texto[:9000], lang='pt', slow=False).save(path)
        return True
    except: return False

# ── Imagens ──────────────────────────────────────────────────────────────────
def gerar_imagens(titulo: str, base: Path) -> list:
    prompts = [
        f"{titulo}, emocional, fotorrealista, luz dramática",
        "cérebro humano neurônios azul roxo futurista",
        "pessoa olhando horizonte pôr do sol esperança",
        "conexão emocional humana calorosa íntima",
        "autoconhecimento espelho reflexão artístico",
        "mãos estendidas suporte emocional",
        f"representação visual abstrata {titulo}",
        "mente subconsciente profundeza oceânica"
    ]
    imgs = []
    out = base / "images"
    out.mkdir(parents=True, exist_ok=True)
    for i, p in enumerate(prompts):
        try:
            url = f"https://image.pollinations.ai/prompt/{requests.utils.quote(p)}?width=1280&height=720&nologo=true&seed={i}"
            r = requests.get(url, timeout=30)
            if r.status_code == 200:
                path = str(out / f"img_{i:03d}.jpg")
                open(path,"wb").write(r.content)
                imgs.append(path)
        except: pass
    return imgs

# ── Vídeo ────────────────────────────────────────────────────────────────────
def montar_video(imgs: list, audio: str, out: str) -> bool:
    try:
        from moviepy.editor import ImageClip, AudioFileClip, concatenate_videoclips
        aud = AudioFileClip(audio)
        dur = aud.duration / max(len(imgs), 1)
        clips = [ImageClip(i, duration=dur) for i in imgs]
        video = concatenate_videoclips(clips, method="compose").set_audio(aud)
        video.write_videofile(out, fps=24, codec="libx264", audio_codec="aac",
                              verbose=False, logger=None)
        return True
    except Exception as e:
        print(f"MoviePy: {e}")
        return False

# ── Thumbnail ────────────────────────────────────────────────────────────────
def gerar_thumbnail(prompt: str, titulo: str, out: str) -> bool:
    p = f"{prompt}, thumbnail YouTube profissional, texto grande '{titulo[:25]}', cores vibrantes"
    try:
        r = requests.get(
            f"https://image.pollinations.ai/prompt/{requests.utils.quote(p)}?width=1280&height=720&nologo=true",
            timeout=30)
        if r.status_code == 200:
            open(out,"wb").write(r.content)
            return True
    except: pass
    return False

# ── YouTube ──────────────────────────────────────────────────────────────────
def yt_token() -> str:
    if not YT_CLIENT_ID: return ""
    r = requests.post("https://oauth2.googleapis.com/token",
        data={"client_id":YT_CLIENT_ID,"client_secret":YT_CLIENT_SECRET,
              "refresh_token":YOUTUBE_TOKEN,"grant_type":"refresh_token"})
    return r.json().get("access_token","") if r.status_code == 200 else ""

def upload_youtube(video: str, thumb: str, roteiro: dict) -> str:
    token = yt_token()
    if not token: return ""
    meta = {"snippet":{"title":roteiro.get("titulo_otimizado",""),
                        "description":roteiro.get("descricao_youtube",""),
                        "tags":roteiro.get("tags",[]),"categoryId":"22"},
            "status":{"privacyStatus":"public","selfDeclaredMadeForKids":False}}
    h = {"Authorization":f"Bearer {token}"}
    r = requests.post(
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
        headers={**h,"Content-Type":"application/json","X-Upload-Content-Type":"video/mp4"},
        json=meta)
    if r.status_code != 200: return ""
    upload_url = r.headers.get("Location","")
    r2 = requests.put(upload_url, headers={**h,"Content-Type":"video/mp4"},
                      data=open(video,"rb").read(), timeout=300)
    if r2.status_code in (200,201):
        vid_id = r2.json().get("id","")
        if vid_id and Path(thumb).exists():
            requests.post(
                f"https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId={vid_id}&uploadType=media",
                headers={**h,"Content-Type":"image/jpeg"},
                data=open(thumb,"rb").read())
        print(f"✅ YouTube: https://youtube.com/watch?v={vid_id}")
        return vid_id
    return ""

# ── Supabase ─────────────────────────────────────────────────────────────────
def salvar(tabela: str, dados: dict):
    if not SUPABASE_URL: return
    requests.post(f"{SUPABASE_URL}/rest/v1/{tabela}",
        headers={"apikey":SUPABASE_KEY,"Authorization":f"Bearer {SUPABASE_KEY}",
                 "Content-Type":"application/json","Prefer":"return=minimal"},
        json=dados, timeout=10)

# ── Pipeline principal ────────────────────────────────────────────────────────
def executar():
    hoje = datetime.date.today().isoformat()
    base = Path(f"/tmp/qb/{hoje}")
    base.mkdir(parents=True, exist_ok=True)

    print("🧠 QUANTUM BRAIN v2.0 — iniciando pipeline...")
    print(f"💰 Afiliados ativos: {len(AFFILIATE_LINKS)} produtos")
    print(f"📊 Maior APV: Billionaire Brain Wave $63.73 | Conversão 3.04%")

    # 1. Trending
    print("\n📊 Pesquisando trending topics...")
    topics = pesquisar_trending()
    titulo = topics[0] if topics else "7 sinais de ansiedade silenciosa"
    print(f"📌 Tópico: {titulo}")

    # 2. Roteiro + links afiliados
    print("\n✍️ Gerando roteiro com links de afiliado...")
    roteiro = gerar_roteiro(titulo)

    # 3. Voz
    print("\n🎙️ Gerando narração...")
    audio = str(base / "audio.mp3")
    gerar_voz(roteiro.get("roteiro_completo", titulo)[:9000], audio)

    # 4. Imagens
    print("\n🖼️ Gerando imagens via Pollinations FLUX...")
    imgs = gerar_imagens(titulo, base)
    print(f"   {len(imgs)} imagens geradas")

    # 5. Vídeo
    print("\n🎬 Montando vídeo...")
    video = str(base / "video.mp4")
    if imgs and Path(audio).exists():
        montar_video(imgs, audio, video)

    # 6. Thumbnail
    print("\n🖼️ Gerando thumbnail...")
    thumb = str(base / "thumbnail.jpg")
    gerar_thumbnail(roteiro.get("prompt_thumbnail", titulo), titulo, thumb)

    # 7. Upload YouTube
    vid_id = ""
    if Path(video).exists() and YT_CLIENT_ID:
        print("\n📤 Publicando no YouTube...")
        vid_id = upload_youtube(video, thumb, roteiro)

    # 8. Salvar log
    salvar("content_log", {
        "date": hoje, "titulo": titulo,
        "video_id": vid_id, "platform": "youtube",
        "status": "published" if vid_id else "generated",
        "affiliate_count": len(AFFILIATE_LINKS)
    })

    # 9. Relatório
    print(f"""
✅ PIPELINE CONCLUÍDO
   Vídeo: {titulo}
   YouTube ID: {vid_id or 'sem credenciais YT ainda'}
   Links afiliados na descrição: {len(AFFILIATE_LINKS)}
   Potencial por venda: $48–$64
   Conversão líder: 3.04% (Billionaire Brain Wave)
""")
    return vid_id

if __name__ == "__main__":
    executar()
